import httpAxios from "./httpAxios";

const ProductService = {
  index: async () => {
    return await httpAxios.get(`product`);
  },
  fetchCategories: async () => {
    return await httpAxios.get(`category`); // Adjust the URL as needed
  },
  fetchBrands: async () => {
    return await httpAxios.get(`brand`); // Adjust the URL as needed
  },
  trash: async () => {
    return await httpAxios.get(`product/trash`);
  },
  show: async (id) => {
    return await httpAxios.get(`product/show/${id}`);
  },
  store: async (data) => {
    return await httpAxios.post(`product/store`, data);
  },
  update: async (data, id) => {
    return await httpAxios.post(`product/update/${id}`, data);
  },
  status: async (id) => {
    return await httpAxios.get(`product/status/${id}`);
  },
  delete: async (id) => {
    return await httpAxios.get(`product/delete/${id}`);
  },
  restore: async (id) => {
    return await httpAxios.get(`product/restore/${id}`);
  },
  destroy: async (id) => {
    return await httpAxios.delete(`product/destroy/${id}`);
  },
};

export default ProductService;
