import httpAxios from "./httpAxios";

const OrderService = {
  index: async () => {
    return await httpAxios.get(`order`);
  },
  trash: async () => {
    return await httpAxios.get(`order/trash`);
  },
  show: async (id) => {
    return await httpAxios.get(`order/show/${id}`);
  },
  insert: async (data) => {
    return await httpAxios.post(`order/insert`, data);
  },
  update: async (data, id) => {
    return await httpAxios.post(`order/update/${id}`, data);
  },
  status: async (id) => {
    return await httpAxios.get(`order/status/${id}`);
  },
  delete: async (id) => {
    return await httpAxios.get(`order/delete/${id}`);
  },
  restore: async (id) => {
    return await httpAxios.get(`order/restore/${id}`);
  },
  destroy: async (id) => {
    return await httpAxios.delete(`order/destroy/${id}`);
  },
};

export default OrderService;
