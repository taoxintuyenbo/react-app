import httpAxios from "./httpAxios";

const UserService = {
  index: async () => {
    return await httpAxios.get(`user`);
  },
  trash: async () => {
    return await httpAxios.get(`user/trash`);
  },
  show: async (id) => {
    return await httpAxios.get(`user/show/${id}`);
  },
  insert: async (data) => {
    return await httpAxios.post(`user/insert`, data);
  },
  update: async (data, id) => {
    return await httpAxios.post(`user/update/${id}`, data);
  },
  status: async (id) => {
    return await httpAxios.get(`user/status/${id}`);
  },
  delete: async (id) => {
    return await httpAxios.get(`user/delete/${id}`);
  },
  restore: async (id) => {
    return await httpAxios.get(`user/restore/${id}`);
  },
  destroy: async (id) => {
    return await httpAxios.delete(`user/destroy/${id}`);
  },
};

export default UserService;
